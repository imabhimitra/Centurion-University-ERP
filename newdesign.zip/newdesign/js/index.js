var cutmApp = angular.module('cutmApp', ['ui.router']);
cutmApp.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', function($stateProvider, $urlRouteProvider, $locationProvider ) {
    $locationProvider.hashPrefix('');
   // $locationProvider.html5Mode(true).hashPrefix('!');
    
    //for configuration pages.......
    
    $stateProvider.state('examCatagory', {
        url: '/examCatagory',
        templateUrl: 'configuration/examCatagory.html'
    })
        .state('examCatagoryNew', {
        url: '/examCatagoryNew',
        templateUrl: 'configuration/examCatagoryNew.html'
    })
        .state('examComponents', {
        url: '/examComponents',
        templateUrl: 'configuration/examComponents.html'
    })
        .state('examRoom', {
        url: '/examRoom',
        templateUrl: 'configuration/examRoom.html'
    })
        .state('grade', {
        url: '/grade',
        templateUrl: 'configuration/grade.html'
    })
        .state('examComp&grade', {
        url: '/examComp&grade',
        templateUrl: 'configuration/examComp&grade.html'
    })
        .state('examCompWeight', {
        url: '/examCompWeight',
        templateUrl: 'configuration/examCompWeight.html'
    })
        .state('improvementType', {
        url: '/improvementType',
        templateUrl: 'configuration/improvementType.html'
    })
        .state('improvementDates', {
        url: '/improvementDates',
        templateUrl: 'configuration/improvementDates.html'
    })
        .state('avg&resultName', {
        url: '/avg&resultName',
        templateUrl: 'configuration/avg&resultName.html'
    })
        .state('disallowReason', {
        url: '/disallowReason',
        templateUrl: 'configuration/disallowReason.html'
    })
    
        //for schedule pages......    
    
        .state('examTimeTableMaster', {
        url: '/examTimeTableMaster',
        templateUrl: 'schedule/examTimeTableMaster.html'
    })
        .state('gradeDifinition', {
        url: '/gradeDifinition',
        templateUrl: 'schedule/gradeDifinition.html'
    })
        .state('examSchedule', {
        url: '/examSchedule',
        templateUrl: 'schedule/examSchedule.html'
    })
        .state('uploadQusPaper', {
        url: '/uploadQusPaper',
        templateUrl: 'schedule/uploadQusPaper.html'
    })
        .state('invigilationChart', {
        url: '/invigilationChart',
        templateUrl: 'schedule/invigilationChart.html'
    })
        .state('allotInvg&candi', {
        url: '/allotInvg&candi',
        templateUrl: 'schedule/allotInvg&candi.html'
    })
    
        //for candidate pages.....
    
        .state('candiExam', {
        url: '/candiExam',
        templateUrl: 'candidate/candiExam.html'
    })
        .state('issueAdmitCard', {
        url: '/issueAdmitCard',
        templateUrl: 'candidate/issueAdmitCard.html'
    })
        .state('examAttendence', {
        url: '/examAttendence',
        templateUrl: 'candidate/examAttendence.html'
    })
        .state('genSittingPlan', {
        url: '/genSittingPlan',
        templateUrl: 'candidate/genSittingPlan.html'
    })
        .state('pushToEMS', {
        url: '/pushToEMS',
        templateUrl: 'candidate/pushToEMS.html'
    })
    
        //for result pages.....
    
        .state('publishResult', {
        url: '/publishResult',
        templateUrl:'result/publishResult.html'
    })
        .state('updateStdGrade', {
        url: '/updateStdGrade',
        templateUrl:'result/updateStdGrade.html'
    })
        .state('assignFacultyForImpReg', {
        url: '/assignFacultyForImpReg',
        templateUrl:'result/assignFacultyForImpReg.html'
    })
        .state('publishImpExamResult', {
        url: '/publishImpExamResult',
        templateUrl:'result/publishImpExamResult.html'
    })
        .state('uploadImpGrade', {
        url: '/uploadImpGrade',
        templateUrl:'result/uploadImpGrade.html'
    })
    
        //for report pages.....
    
        .state('examLevels', {
        url: '/examLevels',
        templateUrl:'summeryReports/examLevels.html'
    })
        .state('invigiChartReport', {
        url: '/invigiChartReport',
        templateUrl:'summeryReports/invigiChartReport.html'
    })
        .state('seatingPlanReport', {
        url: '/seatingPlanReport',
        templateUrl:'summeryReports/seatingPlanReport.html'
    })
        .state('comulativeReport', {
        url: '/comulativeReport',
        templateUrl:'summeryReports/comulativeReport.html'
    })
        .state('semWiseExamScheduleReport', {
        url: '/semWiseExamScheduleReport',
        templateUrl:'summeryReports/semWiseExamScheduleReport.html'
    })
        .state('resultSheet', {
        url: '/resultSheet',
        templateUrl:'summeryReports/resultSheet.html'
    })
        .state('acadamicPerReport', {
        url: '/acadamicPerReport',
        templateUrl:'summeryReports/acadamicPerReport.html'
    })
        .state('semWiseStdPerReport', {
        url: '/semWiseStdPerReport',
        templateUrl:'summeryReports/semWiseStdPerReport.html'
    })  
        .state('provitionalTrans', {
        url: '/provitionalTrans',
        templateUrl:'summeryReports/provitionalTrans.html'
    })
        .state('signSheetReport', {
        url: '/signSheetReport',
        templateUrl:'summeryReports/signSheetReport.html'
    })
        .state('examAtten&MalReport', {
        url: '/examAtten&MalReport',
        templateUrl:'summeryReports/examAtten&MalReport.html'
    })
        .state('examSubReport', {
        url: '/examSubReport',
        templateUrl:'summeryReports/examSubReport.html'
    });
    
    $urlRouteProvider.otherwise('/');
}]);

cutmApp.controller('cont',['$scope',function($scope){
    var info=[    {fn:"Mohamed", 
					mn:"bhai",
					ln:"Sohel",
					gen:"male",
					dob:"1996/6/06",
					ms:"single"
					}];
                  $scope.info=info;
					var f="sohel";
					$scope.f=f;
}]);